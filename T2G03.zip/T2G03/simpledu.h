#ifndef SIMPLEDU_H
#define SIMPLEDU_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "regfile.h"
#include "flags.h"
#include "scan.h"

#endif /*SIMPLEDU_H*/